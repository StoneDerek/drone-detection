# Acoustic drone detection

A local product for uploading audio, reviewing timestamped drone-presence scores,
playing/seeking the recording, inspecting alarm intervals, and exporting results.
It includes real-audio training and reproducible source-aware evaluation.

**Research prototype:** publisher recording labels are weak supervision. Field
reliability, event recall, false alarms per hour, range and live capture are not
established. The [real results and failures](reports/real-v2/RESULTS.md) state what
passed and failed; the interface uses “No alarm” rather than claiming absence.

## Run the product

Python 3.12 and uv are required. From this checkout:

```bash
bash scripts/setup.sh
bash scripts/start.sh
```

The server prints its local address. Upload WAV, FLAC or OGG audio (up to 64 MB and
10 minutes), select **Analyze recording**, then play or seek the timeline. Download
scores as JSON. When the evaluation audio is present, the examples include fixed
positive, ordinary-negative and mechanical-negative inputs, plus a clearly labeled
observed-failure appendix. Upload analysis works without the evaluation corpus.

The timeline also flags clipping and strong low-frequency energy. Listen to the
flagged sections when reviewing a result; these checks do not identify wind or
measure SNR. Quality flags never suppress an alarm. Silent and insufficient
audio have their own display states. See the [0.2 product package](artifacts/product-v0.2/README.md)
for the installable update and verification evidence.

The model and all required statistics/encoder files are bundled in
`artifacts/real-v2/candidate`. Inference does not download weights or contact an
external service. Uploaded audio is processed locally and its temporary file is
removed after analysis. The app supports recorded replay; it does not advertise
microphone capture or a validated physical distance/SNR range.

## File and recorded-stream commands

```bash
.venv/bin/drone-detector infer --bundle artifacts/real-v2/candidate \
  --audio /path/to/recording.wav --output runs/my-file-scores.jsonl
.venv/bin/drone-detector stream --realtime --bundle artifacts/real-v2/candidate \
  --audio /path/to/recording.wav --output runs/my-replay-scores.jsonl
bash scripts/check.sh
```

File and stream commands share the same preprocessing and alarm engine. They use
mono 16 kHz audio, three-second context and a half-second step; short/padded tails,
silence and insufficient context are explicit. Stereo file input is averaged.
For a microphone array, select one physical channel first, as the dataset scripts
do. Scores are uncalibrated classifier outputs. Each trace identifies the model.

## Real data and experiments

The data comes from the author-linked **Kaggle D3Set** mirror, Svanstrom,
**real-field DDL** on Zenodo, Batear, and ESC environmental recordings. DDL's
synthetic archive is excluded. Original/member hashes, licenses, flight/session
identities, grouped splits and weak-label evidence are recorded in the manifest.
Raw third-party audio remains outside tracked source/artifact files.

The first real assessment failed: the selected detector found only 3/48 positive
files. That assessment was explicitly consumed for development, not recycled as
fresh evidence. Version 2 broadens positive sources, corrects duration-biased
threshold selection, and reserves new field days and negative source IDs.
Read the [brief investigation](docs/real-data-investigation.md) and
[full assessment](reports/real-v2/RESULTS.md), including source breakdowns and errors.
File/window counts are not independent flight or session counts.

Pinned scripts reproduce the data workflow:

```bash
.venv/bin/python scripts/fetch_public_audio.py
# Download D3Set version 1 from the Kaggle URL below into runs/real-v1/downloads/.
.venv/bin/python scripts/prepare_real_audio.py
.venv/bin/python scripts/ddl_audio.py
.venv/bin/python scripts/prepare_real_v2.py
.venv/bin/python scripts/fetch_yamnet.py
.venv/bin/python scripts/train_real_v2.py
```

D3Set v1 download:
`https://www.kaggle.com/api/v1/datasets/download/francoismarcoux1212/d3set-introlab?datasetVersionNumber=1`
Save it as `runs/real-v1/downloads/kaggle-d3set-v1.zip`. The scripts verify the pinned
archive and original Git/LFS content. Source scripts stop rather than substituting
missing statistics or accepting changed bytes. Interrupted v2 preparation supports
`--resume`, which verifies cached downloads. Existing published model packages
are preserved. Initial v1 source/split construction is documented in
[the earlier workflow](docs/legacy-workflow.md); its synthetic measurements are
software checks only.

Training/tuning uses development data only. `scripts/train_real_v2.py --assess`
opens the fresh assessment **once**, after freezing both arms and demonstration
IDs. Its local final-use ledger refuses another assessment on that corpus.
If errors guide further training, keep the set as development and obtain fresh
assessment recordings. Replaying an existing frozen model does not create new
independent evidence.

The supplied acoustic-detection article guides the
[next product experiment](reports/context-gain-v1/RESULTS.md): bounded gain
normalization within each available context, compared on the same real training
and development data. It is an opt-in development experiment; the assessed
version-2 model remains the default. The article's quoted ranges and network
interception rates are not product specifications or classifier evidence.

## Evidence and limits

- [Model/source results, thresholds, durations and failures](reports/real-v2/RESULTS.md)
- [Model package](artifacts/real-v2/README.md)
- [Original event-level contract](contracts/evaluation-v1.json)
- [Manifest and label conventions](data/README.md)
- [Collection/annotation protocol](docs/collection-protocol.md)

The full original project archive is still optional material for future auditing;
it is not a prerequisite to running this product. A field-readiness claim needs
more independent capture days/devices and independently reviewed event boundaries
and negative stretches. The portfolio page and environment publication are separate
work. This task does not publish the environment or deploy the app externally.
