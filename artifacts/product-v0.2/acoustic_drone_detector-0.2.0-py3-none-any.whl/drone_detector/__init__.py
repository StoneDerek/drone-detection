"""Experimental acoustic detection; see the evaluation contract before use."""

__version__ = "0.2.0"
