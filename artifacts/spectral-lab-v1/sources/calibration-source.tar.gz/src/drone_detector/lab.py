"""Local model comparison and genuine convolutional Grad-CAM inspection."""

import base64
import io
import json
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import numpy as np
import soundfile as sf
from threadpoolctl import threadpool_limits

from .audio import decode
from .common import read_json
from .model import load_model
from .spectrogram import axes
from .stream import alarm_intervals, replay_audio

PAGE = """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Audio model lab</title><style>
:root{color-scheme:dark;font:15px system-ui;background:#0c171d;color:#e8f2f3}body{max-width:1240px;margin:auto;padding:28px}h1{font-size:32px;margin-bottom:6px}p{line-height:1.5;color:#b4c8ce}.tag{color:#77dcbc;text-transform:uppercase;letter-spacing:2px;font-size:12px}.card{background:#15272f;border:1px solid #2c444d;border-radius:14px;padding:22px;margin:20px 0}.notice{border-left:3px solid #e8b569;padding:12px 18px;background:#31291f;color:#f3d7aa}button,select,input{font:inherit}button,select,input[type=number]{background:#26464d;color:#eef8f8;border:1px solid #527778;border-radius:6px;padding:9px}button{cursor:pointer}button:disabled{opacity:.4;cursor:wait}.bar{display:flex;gap:14px;align-items:center;flex-wrap:wrap}.models{display:flex;gap:12px;flex-wrap:wrap}.models label{background:#213b43;padding:9px;border-radius:6px}audio{width:100%;margin:18px 0}canvas{width:100%;background:#0d1c24;border-radius:6px}.plots{display:grid;grid-template-columns:1fr 1fr;gap:20px}.plots canvas{height:360px}.plots h3{font-size:16px}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:9px;text-align:left;border-bottom:1px solid #2e464e}code{font-size:12px;overflow-wrap:anywhere}.scroll{overflow:auto}.error{color:#ffac9b}.status{color:#8ce2c5}.mini{font-size:13px}input[type=number]{width:90px}#chart{height:220px}.legend{display:flex;gap:14px;flex-wrap:wrap}@media(max-width:750px){body{padding:15px}.plots{grid-template-columns:1fr}.card{padding:16px}}
</style><span class="tag">Recorded audio · model comparison</span><h1>Audio model lab</h1>
<p>Compare neural and non-neural scores. Inspect the spectrogram and the CNN's Grad-CAM for the same audio context.</p>
<p class="notice" id="scope">Loading models…</p>
<section class="card"><div class="bar"><input id="file" type="file" accept="audio/*,.wav,.flac,.ogg"><button id="analyze" disabled>Compare selected models</button></div>
<p>WAV / FLAC / OGG · up to 64 MB and 2 minutes. Audio is processed locally; server temporary files are removed after each request.</p>
<div id="models" class="models"></div><p id="progress" role="status"></p><p id="error" class="error" role="alert"></p></section>
<section class="card" id="result" hidden><audio id="player" controls></audio><div id="legend" class="legend"></div><canvas id="chart" width="1200" height="240"></canvas>
<p>Scores are uncalibrated and cannot be compared as probabilities. Each alarm uses its own development-selected threshold and confirmation rule.</p>
<div class="scroll"><table><thead><tr><th>Model</th><th>Score at playback time</th><th>Alarm / input</th><th>Quality flags</th></tr></thead><tbody id="decisions"></tbody></table></div>
<div class="bar"><button id="export">Download comparison JSON</button><span id="duration"></span></div></section>
<section class="card" id="explanation" hidden><h2>Inspect a CNN decision</h2><div class="bar">
<label>Model <select id="cnn"></select></label><label>Context <select id="window"></select></label>
<label>Target <select id="target"><option value="drone">Drone logit</option><option value="non_drone">Non-drone logit</option></select></label>
<label>Layer <select id="layer"><option value="features">Final convolution</option><option value="conv2">Middle convolution</option><option value="conv1">First convolution</option></select></label>
<button id="explain">Compute Grad-CAM</button></div><p id="camstatus" role="status"></p>
<div class="bar"><label>Frequency from <input id="fmin" type="number" min="0" max="8000" value="50"> Hz</label><label>to <input id="fmax" type="number" min="1" max="8000" value="7600"> Hz</label><button id="zoom">Apply frequency zoom</button><button id="camdownload" disabled>Download explanation JSON</button></div>
<div class="plots"><div><h3>Model input spectrogram</h3><canvas id="spec" width="580" height="360"></canvas></div><div><h3>Grad-CAM overlay</h3><canvas id="cam" width="580" height="360"></canvas></div></div>
<p id="tensor"></p><p class="mini">The horizontal axis is time within the selected context; low frequencies are at the bottom. The vertical axis follows the model's linear or mel bin locations. Warm overlay colours mark positive attribution to the selected logit. A zero map is reported rather than filled with invented detail. Grad-CAM is computed from gradients of the trained CNN, at the selected layer's native resolution; interpolation adds no explanatory detail. Attribution can reveal shortcuts but does not prove a useful or causal acoustic cue.</p>
<h3>Training history for selected CNN</h3><canvas id="learning" width="1100" height="190" style="height:190px"></canvas><p class="mini">Green: balanced training objective including regularization. Orange: balanced development bag loss, checked every two epochs. White dashed line: selected checkpoint. The two losses have different sampling/regularization terms; values are not accuracies.</p></section>
<section class="card"><h2>Training and development evidence</h2><p id="data"></p><div class="scroll"><table><thead><tr><th>Model</th><th>Method</th><th>Input tensor / descriptor</th><th>Development positives detected</th><th>Negative files alarmed</th><th>Selected epoch</th></tr></thead><tbody id="inventory"></tbody></table></div>
<p>Frequency-axis warping, log intensity and tensor shape are separate choices. These models use the same real training/development protocol. Counts describe correlated publisher-labeled files. The previously assessed default is preserved; this lab supplies development evidence.</p></section>
<script>
const el=id=>document.getElementById(id);let catalog,file,objectUrl,result,explanation;const colors=['#8de4c5','#f5c376','#97baff','#e9a5e5','#f09886','#c8d68d','#aeb5ed','#78d1dc','#dcae8e'];
async function load(){try{catalog=await(await fetch('/api/models')).json();el('scope').textContent=catalog.scope;el('data').textContent=catalog.data_summary;
for(const [i,m] of catalog.models.entries()){const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.value=m.name;input.checked=catalog.defaults.includes(m.name);label.append(input,document.createTextNode(' '+m.name));el('models').append(label);
const row=document.createElement('tr');for(const value of [m.name,m.method,m.shape,m.development,m.false_positives,m.selected_epoch||'—']){const td=document.createElement('td');td.textContent=value;row.append(td)}el('inventory').append(row)}
}catch(e){el('error').textContent=e.message}}
el('file').onchange=e=>{if(!e.target.files[0])return;file=e.target.files[0];if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=URL.createObjectURL(file);el('player').src=objectUrl;el('analyze').disabled=false;el('result').hidden=true;el('explanation').hidden=true;el('error').textContent='';result=null;explanation=null};
el('analyze').onclick=async()=>{const names=[...el('models').querySelectorAll('input:checked')].map(x=>x.value);if(!file||!names.length){el('error').textContent='Choose audio and at least one model.';return}el('analyze').disabled=true;el('file').disabled=true;el('error').textContent='';el('progress').textContent='Analyzing complete recording with selected models…';try{const response=await fetch('/api/analyze?models='+encodeURIComponent(names.join(',')),{method:'POST',body:file});const data=await response.json();if(!response.ok)throw Error(data.error);result=data;el('result').hidden=false;el('duration').textContent=data.audio.duration_seconds.toFixed(2)+' s recorded audio · '+data.processing_seconds.toFixed(2)+' s total processing';el('progress').textContent='Comparison complete. Play or seek to inspect decisions.';
el('legend').replaceChildren();el('cnn').replaceChildren();let cnns=0;for(const [i,m] of data.models.entries()){const name=document.createElement('span');name.style.color=colors[i%colors.length];name.textContent=m.name;el('legend').append(name);if(m.gradcam){const option=document.createElement('option');option.value=m.name;option.textContent=m.name;el('cnn').append(option);cnns++}}el('explanation').hidden=!cnns;explanation=null;populateWindows();update()}catch(e){el('error').textContent=e.message;el('progress').textContent='Comparison did not complete.'}finally{el('analyze').disabled=false;el('file').disabled=false}};
function selectedCNN(){return result&&result.models.find(m=>m.name===el('cnn').value)}
function invalidateExplanation(){explanation=null;el('camdownload').disabled=true;el('camstatus').textContent='Compute Grad-CAM for the selected model, context and target.';el('tensor').textContent='';for(const id of ['spec','cam']){const c=el(id);c.getContext('2d').clearRect(0,0,c.width,c.height)}}
function populateWindows(){el('window').replaceChildren();const m=selectedCNN();if(!m)return;for(const row of m.trace){const option=document.createElement('option');option.value=row.window_start_seconds;option.textContent=row.window_start_seconds.toFixed(2)+'–'+row.timestamp_seconds.toFixed(2)+' s'+(row.padded?' · padded':'');el('window').append(option)}drawLearning();invalidateExplanation()}el('cnn').onchange=populateWindows;for(const id of ['window','target','layer'])el(id).onchange=invalidateExplanation;
function drawLearning(){const model=catalog.models.find(m=>m.name===el('cnn').value),history=model?.history||[],c=el('learning'),ctx=c.getContext('2d'),w=c.width,h=c.height,p=30;ctx.clearRect(0,0,w,h);if(!history.length)return;const max=Math.max(.01,...history.flatMap(r=>[r.training_loss,r.development_balanced_bag_loss||0]))*1.1,n=history.at(-1).epoch,x=e=>p+(w-2*p)*(e-1)/Math.max(1,n-1),y=v=>h-p-(h-2*p)*v/max;ctx.strokeStyle='#435e68';ctx.strokeRect(p,p,w-2*p,h-2*p);for(const [field,color] of [['training_loss','#8de4c5'],['development_balanced_bag_loss','#f5c376']]){ctx.strokeStyle=color;ctx.beginPath();let first=true;for(const r of history){if(r[field]===undefined)continue;if(first){ctx.moveTo(x(r.epoch),y(r[field]));first=false}else ctx.lineTo(x(r.epoch),y(r[field]))}ctx.stroke()}ctx.strokeStyle='white';ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(x(model.selected_epoch),p);ctx.lineTo(x(model.selected_epoch),h-p);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#c5d8dc';ctx.font='13px system-ui';ctx.fillText('Epoch 1',p,h-8);ctx.fillText('Epoch '+n,w-85,h-8);ctx.fillText(max.toFixed(2),0,p);ctx.fillText('0',6,h-p)}
function update(){if(!result)return;const time=el('player').currentTime;el('decisions').replaceChildren();for(const m of result.models){const row=m.trace.filter(r=>r.timestamp_seconds<=time+.001).at(-1);const tr=document.createElement('tr');for(const text of [m.name,row?(row.score===null?'—':row.score.toFixed(4)):'Waiting for context',row?(row.alarm?'ALARM':row.reason==='silence'?'Silent input':row.reason==='insufficient_audio'?'Insufficient audio':'No alarm'):'Waiting',(row?.quality_flags||[]).join(', ')||'—']){const td=document.createElement('td');td.textContent=text;tr.append(td)}el('decisions').append(tr)}
const c=el('chart'),ctx=c.getContext('2d'),w=c.width,h=c.height,p=24,x=t=>p+(w-2*p)*t/result.audio.duration_seconds,y=s=>h-p-(h-2*p)*s;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#405d68';ctx.strokeRect(p,p,w-2*p,h-2*p);for(const [i,m] of result.models.entries()){ctx.strokeStyle=colors[i%colors.length];ctx.beginPath();let first=true;for(const r of m.trace){if(r.score===null)continue;if(first){ctx.moveTo(x(r.timestamp_seconds),y(r.score));first=false}else ctx.lineTo(x(r.timestamp_seconds),y(r.score))}ctx.stroke()}ctx.strokeStyle='#ffffff';ctx.beginPath();ctx.moveTo(x(time),p);ctx.lineTo(x(time),h-p);ctx.stroke();
const cnn=selectedCNN(),row=cnn?.trace.filter(r=>r.timestamp_seconds<=time+.001).at(-1);if(row&&el('window').value!==String(row.window_start_seconds)){el('window').value=row.window_start_seconds;invalidateExplanation()}}
el('player').addEventListener('timeupdate',update);el('player').addEventListener('seeked',update);
function download(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}el('export').onclick=()=>download(result,'audio-model-comparison.json');el('camdownload').onclick=()=>download(explanation,'gradcam-explanation.json');
el('explain').onclick=async()=>{if(!file||!selectedCNN())return;el('explain').disabled=true;el('camstatus').textContent='Computing gradients for the selected context…';try{const query=new URLSearchParams({model:el('cnn').value,start:el('window').value,target:el('target').value,layer:el('layer').value});const response=await fetch('/api/explain?'+query,{method:'POST',body:file});const data=await response.json();if(!response.ok)throw Error(data.error);explanation=data;el('camdownload').disabled=false;el('camstatus').textContent='Context '+data.start_seconds.toFixed(2)+'–'+data.end_seconds.toFixed(2)+' s · classifier score '+data.classifier_score.toFixed(4)+' · target '+data.target+' · '+(data.has_positive_attribution?'positive attribution shown':'zero positive-attribution map');el('tensor').textContent=data.axis+' frequency axis · '+data.intensity+' intensity · input ['+data.shape.join(', ')+', 1] · Hann window '+(1000*data.n_fft/16000).toFixed(0)+' ms · FFT spacing '+(16000/data.n_fft).toFixed(2)+' Hz · Grad-CAM native grid '+data.coarse_shape.join(' × ')+'. Display arrays are quantized to 8 bits; model inputs use float32.';drawExplanation()}catch(e){el('camstatus').textContent=e.message}finally{el('explain').disabled=false}};
function unpack(value){return Uint8Array.from(atob(value),c=>c.charCodeAt(0))}
function drawExplanation(){if(!explanation)return;const data=explanation,spec=unpack(data.spectrogram_u8),cam=unpack(data.heatmap_u8),[f,t]=data.shape,lo=Number(el('fmin').value),hi=Number(el('fmax').value),bins=data.frequencies_hz.map((v,i)=>v>=lo&&v<=hi?i:-1).filter(i=>i>=0);if(!bins.length){el('camstatus').textContent='Choose a frequency range containing model bins.';return}
for(const id of ['spec','cam']){const target=el(id),ctx=target.getContext('2d'),buffer=document.createElement('canvas');buffer.width=t;buffer.height=bins.length;const bctx=buffer.getContext('2d'),pixels=bctx.createImageData(t,bins.length);for(let y=0;y<bins.length;y++)for(let x=0;x<t;x++){const source=bins[bins.length-1-y]*t+x,p=(y*t+x)*4,v=spec[source]/255,a=id==='cam'?.7*cam[source]/255:0;const rgb=[20+210*v,25+170*v,45+100*v];pixels.data[p]=rgb[0]*(1-a)+255*a;pixels.data[p+1]=rgb[1]*(1-a)+65*a;pixels.data[p+2]=rgb[2]*(1-a)+30*a;pixels.data[p+3]=255}bctx.putImageData(pixels,0,0);ctx.clearRect(0,0,target.width,target.height);ctx.imageSmoothingEnabled=false;ctx.drawImage(buffer,45,18,target.width-62,target.height-50);ctx.fillStyle='#d3e4e6';ctx.font='12px system-ui';ctx.fillText(Math.round(data.frequencies_hz[bins.at(-1)])+' Hz',3,14);ctx.fillText(Math.round(data.frequencies_hz[bins[0]])+' Hz',3,target.height-30);ctx.fillText(data.frame_times_seconds[0].toFixed(2)+' s',45,target.height-8);ctx.fillText(data.frame_times_seconds.at(-1).toFixed(2)+' s',target.width-60,target.height-8)}}el('zoom').onclick=drawExplanation;load();
</script></html>"""


def make_lab_server(catalog_path, host='127.0.0.1', port=8000):
    catalog_path = Path(catalog_path).resolve()
    catalog = read_json(catalog_path)
    models = {row['name']: load_model(catalog_path.parent / row['bundle'], True) for row in catalog['models']}
    if not models or len(models) != len(catalog['models']):
        raise ValueError('Catalog needs unique model names')
    for model in models.values():
        if model.config.sample_rate != 16000:
            raise ValueError('Lab comparison requires canonical 16kHz models')
        if hasattr(model, 'warmup'):
            model.warmup()
        elif model.encoder is not None:
            model.score(np.zeros(model.config.window_samples, dtype=np.float32))
    lock = threading.RLock()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def respond(self, payload, status=200, html=False):
            data = payload.encode() if html else json.dumps(payload, allow_nan=False).encode()
            try:
                self.send_response(status)
                self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                self.close_connection = True

        def do_GET(self):
            if self.path == '/':
                return self.respond(PAGE, html=True)
            if self.path == '/api/models':
                inventory = []
                for name, model in models.items():
                    meta = model.metadata
                    chosen = meta['selection']['chosen']['metrics']
                    is_spectral = meta['schema_version'] == 2
                    shape = [len(axes(model.config)[0]), len(axes(model.config)[1]), 1] if is_spectral else meta['feature_dimension']
                    inventory.append({'name': name, 'model_id': model.model_id,
                        'method': {'spectrogram_cnn': 'Trainable 2D CNN', 'rbf_svm': 'RBF SVM · no neural encoder',
                                   'yamnet': 'Frozen YAMNet + logistic regression',
                                   'relative_mel': 'Spectral summaries + logistic regression · no neural encoder'}.get(
                            meta.get('family', meta['features'].get('representation')), 'Experimental classifier'),
                        'shape': str(shape) + (' → per-frequency mean/std' if meta.get('family') == 'rbf_svm' else ''),
                        'gradcam': meta.get('family') == 'spectrogram_cnn',
                        'development': f"{chosen['confusion']['tp']}/{chosen['positive_recordings']}" if 'confusion' in chosen else 'Not recording-level',
                        'false_positives': f"{chosen['confusion']['fp']}/{chosen['negative_recordings']}" if 'confusion' in chosen else 'Not recording-level',
                        'selected_epoch': meta['training'].get('selected_epoch'),
                        'history': meta['training'].get('history', []),
                        'decision': meta['decision'], 'features': meta['features']})
                return self.respond({'models': inventory, 'scope': catalog['scope'],
                    'data_summary': catalog['data_summary'], 'defaults': catalog['defaults']})
            return self.respond({'error': 'Not found'}, 404)

        def do_POST(self):
            parsed = urlparse(self.path)
            if parsed.path not in {'/api/analyze', '/api/explain'}:
                return self.respond({'error': 'Not found'}, 404)
            origin = self.headers.get('Origin')
            if origin and urlparse(origin).netloc != self.headers.get('Host'):
                return self.respond({'error': 'Cross-origin upload is not supported'}, 403)
            try:
                length = int(self.headers.get('Content-Length', 0))
                if not 0 < length <= 64 * 1024 * 1024:
                    return self.respond({'error': 'Choose audio up to 64 MB'}, 413)
                raw = self.rfile.read(length)
                info = sf.info(io.BytesIO(raw))
                if not 0 < info.duration <= 120 or info.channels > 16:
                    return self.respond({'error': 'Use nonempty audio up to 2 minutes and 16 channels'}, 422)
                begin = time.perf_counter()
                with tempfile.TemporaryDirectory(prefix='audio-lab-') as directory:
                    path = Path(directory) / 'recording.audio'
                    path.write_bytes(raw)
                    audio, details = decode(path)
                query = parse_qs(parsed.query)
                with lock, threadpool_limits(limits=1):
                    if parsed.path == '/api/analyze':
                        names = query.get('models', [''])[0].split(',')
                        if len(names) > 12 or not all(name in models for name in names):
                            raise ValueError('Select models from the catalog')
                        result = []
                        for name in names:
                            model = models[name]
                            trace = model.batch_trace(audio) if hasattr(model, 'batch_trace') else replay_audio(model, audio)
                            result.append({'name': name, 'model_id': model.model_id, 'trace': trace,
                                'decision': model.metadata['decision'], 'gradcam': model.metadata.get('family') == 'spectrogram_cnn',
                                'alarms': alarm_intervals(trace, details['duration_seconds'], merge_gap=1)})
                        return self.respond({'models': result, 'audio': details,
                            'processing_seconds': time.perf_counter() - begin, 'scope': catalog['scope']})
                    name = query.get('model', [''])[0]
                    if name not in models or models[name].metadata.get('family') != 'spectrogram_cnn':
                        raise ValueError('Select a trained convolutional model for Grad-CAM')
                    model = models[name]
                    start = float(query.get('start', ['0'])[0])
                    if not np.isfinite(start) or not 0 <= start < details['duration_seconds']:
                        raise ValueError('Context start is outside the recording')
                    offset = round(start * model.config.sample_rate)
                    wave = audio[offset:offset + model.config.window_samples]
                    values = model.gradcam(wave, query.get('target', ['drone'])[0], query.get('layer', ['features'])[0])
                    frequencies, times, _ = axes(model.config)
                    response = {k: v for k, v in values.items() if k not in {'spectrogram', 'heatmap'}}
                    for key in ['spectrogram', 'heatmap']:
                        pixels = np.clip(np.rint(values[key] * 255), 0, 255).astype(np.uint8)
                        response[key + '_u8'] = base64.b64encode(pixels.tobytes()).decode()
                    response.update({'name': name, 'model_id': model.model_id, 'shape': list(values['spectrogram'].shape),
                        'frequencies_hz': frequencies.tolist(), 'frame_times_seconds': (times + start).tolist(),
                        'start_seconds': start, 'end_seconds': (offset + len(wave)) / model.config.sample_rate,
                        'padded': len(wave) < model.config.window_samples, 'axis': model.config.axis,
                        'intensity': model.config.intensity, 'n_fft': model.config.n_fft,
                        'encoding': 'row-major frequency × time uint8 display arrays, base64; model input is float32',
                        'scope': 'Grad-CAM attribution to a classifier logit, not a causal explanation or reliability evidence'})
                    return self.respond(response)
            except (ValueError, OSError, RuntimeError, KeyError) as error:
                return self.respond({'error': str(error) if isinstance(error, ValueError) else 'Unable to analyze this audio. Use WAV, FLAC or OGG.'}, 422)

    return ThreadingHTTPServer((host, port), Handler)


def serve_lab(catalog, host='127.0.0.1', port=8000):
    server = make_lab_server(catalog, host, port)
    print(f'Audio model lab running at http://{host}:{server.server_port}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
